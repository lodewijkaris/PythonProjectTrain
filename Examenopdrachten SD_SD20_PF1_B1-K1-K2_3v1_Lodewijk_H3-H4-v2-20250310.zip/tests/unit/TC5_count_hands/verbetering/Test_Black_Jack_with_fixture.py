import pytest
import time
from BlackJack_count_hands import calculate_hand_value

@pytest.fixture
def hands():
    return {
        "no_aces_no_tens": [('2', 'Hearts'), ('3', 'Diamonds'), ('4', 'Clubs')],
        "with_face_cards": [('Jack', 'Hearts'), ('3', 'Diamonds'), ('King', 'Clubs')],
        "with_aces": [('Ace', 'Hearts'), ('3', 'Diamonds'), ('Ace', 'Clubs')],
        "with_ace_adjustment": [('Ace', 'Hearts'), ('Ace', 'Clubs'), ('10', 'Diamonds')],
        "busting_with_aces": [('Ace', 'Hearts'), ('Ace', 'Diamonds'), ('9', 'Clubs'), ('Ace', 'Spades'), ('10', 'Spades')]
    }

def test_hand_value_no_aces_no_tens(hands):
    hand = hands["no_aces_no_tens"]
    assert calculate_hand_value(hand) == 9
    print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
    time.sleep(0.5)

def test_hand_value_with_face_cards(hands):
    hand = hands["with_face_cards"]
    assert calculate_hand_value(hand) == 23
    print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
    time.sleep(0.5)

def test_hand_value_with_aces(hands):
    hand = hands["with_aces"]
    assert calculate_hand_value(hand) == 15
    print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
    time.sleep(0.5)

def test_hand_value_with_ace_adjustment(hands):
    hand = hands["with_ace_adjustment"]
    assert calculate_hand_value(hand) == 12
    print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
    time.sleep(0.5)

def test_hand_value_busting_with_aces(hands):
    hand = hands["busting_with_aces"]
    assert calculate_hand_value(hand) == 22
    print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
    time.sleep(0.5)
