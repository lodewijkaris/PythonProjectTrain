#Test Case geteld, de opgetelde waarde is correct voor speler en deler

import unittest
import time
from BlackJack_count_hands import calculate_hand_value
class TestBlackJackTC5(unittest.TestCase):
    def test_hand_value_no_aces_no_tens(self):
        hand = [('2', 'Hearts'), ('3', 'Diamonds'), ('4', 'Clubs')]
        self.assertEqual(calculate_hand_value(hand), 9)
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_hand_value_with_face_cards(self):
        hand = [('Jack', 'Hearts'), ('3', 'Diamonds'), ('King', 'Clubs')]
        self.assertEqual(calculate_hand_value(hand), 23)
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_hand_value_with_aces(self):
        hand = [('Ace', 'Hearts'), ('3', 'Diamonds'), ('Ace', 'Clubs')]
        self.assertEqual(calculate_hand_value(hand), 15)
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_hand_value_with_ace_adjustment(self):
        hand = [('Ace', 'Hearts'), ('Ace', 'Clubs'), ('10', 'Diamonds')]
        self.assertEqual(calculate_hand_value(hand), 12)
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_hand_value_busting_with_aces(self):
        hand = [('Ace', 'Hearts'), ('Ace', 'Diamonds'), ('9', 'Clubs'), ('Ace', 'Spades'), ('10', 'Spades')]
        self.assertEqual(calculate_hand_value(hand), 22)
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")


## Extra testcode om enkele en meervoudige azen te testen
class TestBlackJackTC5Aces(unittest.TestCase):

    def test_calculate_hand_value_ace(self):
        # Test hand met een Aas
        hand = [('Ace', 'Hearts')]
        assert calculate_hand_value(hand) == 11, f"Expected 11, got {calculate_hand_value(hand)}"
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_calculate_hand_value_two_aces(self):
        # Test hand met twee Azen
        hand = [('Ace', 'Hearts'), ('Ace', 'Diamonds')]
        assert calculate_hand_value(hand) == 12, f"Expected 12, got {calculate_hand_value(hand)}"
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_calculate_hand_value_three_aces(self):
        # Test hand met meervoudige Azen en andere kaarten
        hand = [('Ace', 'Hearts'), ('Ace', 'Diamonds'), ('Ace', 'Clubs'), ('5', 'Spades')]
        assert calculate_hand_value(hand) == 18, f"Expected 18, got {calculate_hand_value(hand)}"
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_calculate_hand_value_aces_adjusted_to_one(self):
        # Test hand met meervoudige Azen met aanpassing van 11 naar 1
        hand = [('Ace', 'Hearts'), ('Ace', 'Diamonds'), ('10', 'Clubs'), ('5', 'Spades')]
        assert calculate_hand_value(hand) == 17, f"Expected 17, got {calculate_hand_value(hand)}"
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        time.sleep(0.5)
    def test_calculate_hand_value_three_aces_21(self):
        # Test hand met 3 azen
        hand = [('Ace', 'Hearts'), ('Ace', 'Diamonds'), ('Ace', 'Clubs'), ('8', 'Spades')]
        assert calculate_hand_value(hand) == 21, f"Expected 21, got {calculate_hand_value(hand)}"
        print("")
        print(f"Speler heeft nu :{calculate_hand_value(hand)} punten")
        print("Alle testen mat Azen passed!")

if __name__ == '__main__':
    unittest.main()
